// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyDiH_Lp5OtAi5V8ciPep-qBVto-pYf-tb0",
  authDomain: "halseon-website.firebaseapp.com",
  projectId: "halseon-website",
  storageBucket: "halseon-website.appspot.com",
  messagingSenderId: "300703311898",
  appId: "1:300703311898:web:55eb06aeb7eb10e75f49a3"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);